<?php
session_start();
include("header.php");
include("connect.php");

$oid=$_REQUEST['orderid'];
$amt=$_REQUEST['amt'];
unset($_SESSION['cartid']);
?>

	<div class="hero-wrap hero-bread" style="background-image: url('images/abtbbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">THANK YOU FOR YOUR VALUABLE ORDER</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" class="bg-white p-5 contact-form">
              <div class="form-group">
                <H3>Order Id: <?php echo $oid; ?></h3>
              </div>
              <div class="form-group">
                 <H3>Order Total Amount: &#8377; <?php echo $amt; ?> /-</h3>
              </div>
              
              <div class="form-group">
                 <H3>CASH ON DELIEVERY</h3>
              </div>
			  
			  <div class="form-group">
                 <H3>YOUR ORDER WILL BE DELIEVERD ON 5 TO 6 WORKING HOURS</h3>
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
				<img src="images/log1.gif" style="margin-left:100px;">
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>