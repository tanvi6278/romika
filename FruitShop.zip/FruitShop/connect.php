<?php
mysql_connect("localhost","root","") or die("Connection Failed");
mysql_select_db("fruit_shop");
?>