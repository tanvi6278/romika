<?php
session_start();
include("header.php");
include("connect.php");

$fid=$_REQUEST['fid'];
$res1=mysql_query("select * from fruit_detail where fruit_id='$fid'");
$r1=mysql_fetch_array($res1);
$fname=$r1[1];
$catid=$r1[2];
$desc=$r1[3];
$uom=$r1[4];
$price=$r1[5];
$fimg1=$r1[7];
?>
<script type="text/javascript">
function validation()
{
	var v=/^[0-9]+$/
	if(form1.txtqty.value=="")
	{
		alert("Please Select Quantity");
		form1.txtqty.focus();
		return false;
	}else if((parseInt(form1.txtqty.value))<=0)
	{
		alert("Please Select Quantity Greater Than 0");
		form1.txtqty.focus();
		return false;
	}else if((parseInt(form1.txtqty.value))>=20)
	{
		alert("Please Select Quantity Less Than 20");
		form1.txtqty.focus();
		return false;
	}else{
		if(!v.test(form1.txtqty.value))
		{
			alert("Please Enter Only Digit In Quantity");
			form1.txtqty.focus();
			return false;
		}
	}
}
</script>
<?php
if(isset($_POST['btncart']))
{
	$qty=$_POST['txtqty'];
	if(isset($_SESSION['cartid']))
	{
		$cartid=$_SESSION['cartid'];
		//auto number code start...
		$res2=mysql_query("select max(cart_detail_id) from cart_detail");
		$cartdid=0;
		while($r2=mysql_fetch_array($res2))
		{
			$cartdid=$r2[0];
		}
		$cartdid++;
		//auto number code end...
		$query="insert into cart_detail values('$cartdid','$cartid','$fid','$qty','$uom','$price')";
		if(mysql_query($query))
		{
			echo "<script type='text/javascript'>";
			echo "alert('Fruit Added Into Cart');";
			echo "window.location.href='fruits.php';";
			echo "</script>";
		}
	}else{
		//auto number code start...
		$res=mysql_query("select max(cart_id) from cart_master");
		$cartid=0;
		while($r=mysql_fetch_array($res))
		{
			$cartid=$r[0];
		}
		$cartid++;
		//auto number code end...
		$tdate=date("Y-m-d");
		$query="insert into cart_master values('$cartid','$tdate')";
		if(mysql_query($query))
		{
			$_SESSION['cartid']=$cartid;
			//auto number code start...
			$res2=mysql_query("select max(cart_detail_id) from cart_detail");
			$cartdid=0;
			while($r2=mysql_fetch_array($res2))
			{
				$cartdid=$r2[0];
			}
			$cartdid++;
			//auto number code end...
			$query="insert into cart_detail values('$cartdid','$cartid','$fid','$qty','$uom','$price')";
			if(mysql_query($query))
			{
				echo "<script type='text/javascript'>";
				echo "alert('Fruit Added Into Cart');";
				echo "window.location.href='fruits.php';";
				echo "</script>";
			}
		}
	}
}
?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/abtbbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">FRUITS DETAIL</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
			
			<form method="post" name="form1" class="bg-white p-5 contact-form">
			<h4>Fruit Name: <?php echo $fname; ?></h4>
			<h4>Fruit Description: <?php echo $desc; ?></h4>
			<h4>Price: &#8377; <?php echo $price; ?> /- <?php echo $uom; ?> </h4>
              <div class="form-group">
                <input type="number" class="form-control" name="txtqty" placeholder="Enter Your Quantity In <?php echo $uom; ?>">
              </div>
            
              
              <div class="form-group">
                <input type="submit" value="ADD TO CART" name="btncart" onclick="return validation();"class="btn btn-primary py-3 px-5">
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
				<img src="<?php echo $fimg1; ?>" style="width:550px; height:450px;">
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>