<?php
session_start();
include("header.php");
include("connect.php");

if(isset($_REQUEST['dcdid']))
{
	$cdid=$_REQUEST['dcdid'];
	$query="delete from cart_detail where cart_detail_id='$cdid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Fruits Deleted Successfully');";
		echo "window.location.href='cart_detail.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['chkid']))
{
	if(isset($_SESSION['userid']))
	{
		
	}else{
		$_SESSION['chkid']="x";
		header("Location: login.php");
	}
}
?>

	<div class="hero-wrap hero-bread" style="background-image: url('images/abtbbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">MY CART DETAIL</h1>
          </div>
        </div>
      </div>
    </div>

   <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
				
				
    			<div class="col-md-12 ftco-animate">
    				<div class="cart-list">
					<?php 
					$tot=0;
					$cartid=$_SESSION['cartid'];
					$res1=mysql_query("select * from cart_detail where cart_id='$cartid'");
					if(mysql_num_rows($res1)>0)
					{
					?>
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>&nbsp;</th>
						        <th>Fruit Image</th>
						        <th>Fruit Name</th>
						        <th>Price</th>
						        <th>Quantity</th>
						        <th>Total</th>
						      </tr>
						    </thead>
						    <tbody>
						   <?php
						   while($r1=mysql_fetch_array($res1))
						   {
								$res2=mysql_query("select * from fruit_detail where fruit_id='$r1[2]'");
								$r2=mysql_fetch_array($res2);
						   ?>  
							  <tr class="text-center">
						        <td class="product-remove"><a href="cart_detail.php?dcdid=<?php echo $r1[0]; ?>"><span class="ion-ios-close"></span></a>
								<a href="customer_update_qty.php?fid=<?php echo $r1[2]; ?>"><span class="ion-ios-keypad"></span></a>
								</td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(<?php echo $r2[7]; ?>);"></div></td>
						        
						        <td class="product-name">
						        	<h3><?php echo $r2[1]; ?></h3>
						        	
						        </td>
						        
						        <td class="price">&#8377; <?php echo $r1[5]; ?> /- <?php echo $r1[4]; ?></td>
						        
						        <td class="quantity">
						        	<div class="input-group mb-3">
					             	<?php echo $r1[3]; ?> <?php echo $r1[4]; ?>
					          	</div>
					          </td>
						        
						        <td class="total">
								<?php
								$amt=$r1[3]*$r1[5];
								$tot=$tot+$amt;
								echo "&#8377 $amt /-";;
								?>
								
								</td>
						      </tr><!-- END TR-->
						<?php
						}
						?>
						     
						    </tbody>
						  </table>
					<?php
					}else{
						echo "<h2>No Fruits Added Into Cart</h2>";
					}
					?>
					  </div>
    			</div>
    		</div>
    		<div class="row justify-content-end">
    			
    			<div class="col-lg-4 mt-5 cart-wrap ftco-animate">
    				<div class="cart-total mb-3">
    					<h3>Cart Totals</h3>
    					<p class="d-flex">
    						<span>Subtotal</span>
    						<span>&#8377; <?php echo $tot; ?> /-</span>
    					</p>
    					<p class="d-flex">
    						<span>Delivery</span>
    						<span>&#8377; 0.00 /-</span>
    					</p>
    					<p class="d-flex">
    						<span>Discount</span>
    						<span>&#8377; 0.00 /-</span>
    					</p>
    					<hr>
    					<p class="d-flex total-price">
    						<span>Total</span>
    						<span>&#8377; <?php echo $tot; ?> /-</span>
    					</p>
    				</div>
				<?php
				if($tot>0)
				{
				?>
    				<p><a href="cart_detail.php?chkid=x" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p>
				<?php
				}
				?>
    			</div>
    		</div>
			</div>
		</section>
    <hr>
<?php
include("footer.php");
?>