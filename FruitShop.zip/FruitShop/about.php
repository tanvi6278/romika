<?php
include("header.php");
?>

 <div class="hero-wrap hero-bread" style="background-image: url('images/banner5.jpg'); opacity:0.6;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          
            <h1 class="mb-0 bread" style="color:#000000;">About us</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-no-pb ftco-no-pt bg-light">
			<div class="container">
				<div class="row">
					<div class="col-md-5 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/about.jpg);">
						
					</div>
					<div class="col-md-7 py-5 wrap-about pb-md-5 ftco-animate">
	          <div class="heading-section-bold mb-4 mt-md-5">
	          	<div class="ml-md-0">
		            <h2 class="mb-4">About Fruit Shop</h2>
	            </div>
	          </div>
	          <div class="pb-md-5">
	          	 <p align="justify">Fruits play an important part of your daily diet. They are naturally good, provide important vitamins and minerals. They should be consumed daily in good proportions to maintain a healthy life. But visiting markets every now and then can be a little difficult especially in today’s fast-moving world. There comes a need of a reliable online FruitShop where you can find varieties of fruits that are fresh as well as healthy. </p>
				<br/>
				 <p align="justify">Explore our website at fruitshop.com and stock up your weekly necessities. What could be better than getting fresh fruits right on your doorstep plus additional benefits? So, if you are not a fruit fan, then start adding them as a part of your everyday meal and reap its benefits. </p>
						</div>
					</div>
				</div>
			</div>
		</section>

	
		<section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url(images/abtbbanner1.jpg);">
    	<div class="container">
    		<div class="row justify-content-center py-5">
    			<div class="col-md-10">
		    		<div class="row">
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
						<br/><br/>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		               <br/><br/>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		               <br/><br/>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		               <br/><br/><br/><br/><br/><br/><br/><br/>
		              </div>
		            </div>
		          </div>
		        </div>
	        </div>
        </div>
    	</div>
    </section>
		
	

    <hr>
<?php
include("footer.php");
?>