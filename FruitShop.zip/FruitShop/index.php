<?php
include("header.php");
?>

<section id="home-section" class="hero">
		  <div class="home-slider owl-carousel">
	      <div class="slider-item" style="background-image: url(images/banner2.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	            

	          </div>
	        </div>
	      </div>

	      <div class="slider-item" style="background-image: url(images/banner3.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	            

	          </div>
	        </div>
	      </div>
		  <div class="slider-item" style="background-image: url(images/banner6.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	           

	          </div>
	        </div>
	      </div>
	    </div>
    </section>

    <section class="ftco-section">
			<div class="container">
				<div class="row no-gutters ftco-services">
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-1 active d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-shipped"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Free Shipping</h3>
                <span>On All Orders</span>
              </div>
            </div>      
          </div>
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-2 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-diet"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Always Fresh</h3>
                <span>Fruits well package</span>
              </div>
            </div>    
          </div>
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-3 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-award"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Superior Quality</h3>
                <span>Quality Products</span>
              </div>
            </div>      
          </div>
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-4 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-customer-service"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Support</h3>
                <span>24/7 Support</span>
              </div>
            </div>      
          </div>
        </div>
			</div>
		</section>

		<section class="ftco-section ftco-category ftco-no-pt">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<div class="row">
							<div class="col-md-6 order-md-last align-items-stretch d-flex">
								<div class="category-wrap-2 ftco-animate img align-self-stretch d-flex" style="background-image: url(images/category.jpg);">
									<div class="text text-center">
										<h2>Fruits Shop</h2>
										<p>Protect the health of every home</p>
										
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="category-wrap ftco-animate img mb-4 d-flex align-items-end" style="background-image: url(images/side1.jpg);">
									<div class="text px-3 py-1">
										<h2 class="mb-0"><a href="#">Pomes:</a></h2>
									</div>
								</div>
								<div class="category-wrap ftco-animate img d-flex align-items-end" style="background-image: url(images/side2.jpg);">
									<div class="text px-3 py-1">
										<h2 class="mb-0"><a href="#">Berries:</a></h2>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="category-wrap ftco-animate img mb-4 d-flex align-items-end" style="background-image: url(images/side3.jpg);">
							<div class="text px-3 py-1">
								<h2 class="mb-0"><a href="#">Citrus:</a></h2>
							</div>		
						</div>
						<div class="category-wrap ftco-animate img d-flex align-items-end" style="background-image: url(images/side4.jpg);">
							<div class="text px-3 py-1">
								<h2 class="mb-0"><a href="#">Tropical:</a></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

    <section class="ftco-section">
    	<div class="container">
				<div class="row justify-content-center mb-3 pb-3">
          <div class="col-md-12 heading-section text-center ftco-animate">
          	<span class="subheading"></span>
            <h2 class="mb-4">Welcome To Fruit Shop</h2>
            <p>Fruits play an important part of your daily diet. They are naturally good, provide important vitamins and minerals. They should be consumed daily in good proportions to maintain a healthy life. But visiting markets every now and then can be a little difficult especially in today’s fast-moving world. There comes a need of a reliable online FruitShop where you can find varieties of fruits that are fresh as well as healthy. Explore our website at fruitshop.com and stock up your weekly necessities. What could be better than getting fresh fruits right on your doorstep plus additional benefits? So, if you are not a fruit fan, then start adding them as a part of your everyday meal and reap its benefits. </p>
          </div>
        </div>   		
    	</div>
    	
    </section>
		
		<section class="ftco-section img" style="background-image: url(images/banner7.jpg);">
    	<div class="container">
				<div class="row justify-content-end">
          <div class="col-md-6 heading-section ftco-animate deal-of-the-day ftco-animate">
          	<span class="subheading"></span>
            <h2 class="mb-4"></h2>
            <p></p>
            <h3><a href="#"></a></h3>
            
            <div id="timer" class="d-flex mt-5">
			
						</div>
          </div>
        </div>   		
    	</div>
    </section>

    <hr>
<?php
include("footer.php");
?>