<?php
include("admin_header.php");
include("connect.php");

//auto number code start...
$res=mysql_query("select max(cat_id) from fruit_cat");
$catid=0;
while($r=mysql_fetch_array($res))
{
	$catid=$r[0];
}
$catid++;
//auto number code end...
?>
<hr/>
<script type="text/javascript">
function validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtcat.value=="")
	{
		alert("Please Enter Category");
		form1.txtcat.focus();
		return false;
	}else{
		if(!v.test(form1.txtcat.value))
		{
			alert("Please Enter Only Alphabets in Category");
			form1.txtcat.focus();
			return false;
		}
	}
}
</script>
<?php
if(isset($_POST['btnsave']))
{
	$catid=$_POST['txtcatid'];
	$cat=$_POST['txtcat'];
	$query="insert into fruit_cat values('$catid','$cat','0')";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Saved Successfully');";
		echo "window.location.href='admin_manage_cat.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['ucid']))
{
	$catid=$_REQUEST['ucid'];
	$res1=mysql_query("select * from fruit_cat where cat_id='$catid'");
	$r1=mysql_fetch_array($res1);
	$cat1=$r1[1];
}

if(isset($_POST['btnupdate']))
{
	$catid=$_POST['txtcatid'];
	$cat=$_POST['txtcat'];
	$query="update fruit_cat set category='$cat' where cat_id='$catid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Updated Successfully');";
		echo "window.location.href='admin_manage_cat.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['dcid']))
{
	$catid=$_REQUEST['dcid'];
	$query="update fruit_cat set cat_status='1' where cat_id='$catid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Invisible Successfully');";
		echo "window.location.href='admin_manage_cat.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['scid']))
{
	$catid=$_REQUEST['scid'];
	$query="update fruit_cat set cat_status='0' where cat_id='$catid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Visible Successfully');";
		echo "window.location.href='admin_manage_cat.php';";
		echo "</script>";
	}
}
?>
    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	 <div class="col-md-12 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">MANAGE CATEGORY</h1>
          </div>
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" name="form1" class="bg-white p-5 contact-form">
              <div class="form-group">
                <input type="text" class="form-control" name="txtcatid" placeholder="Enter Category Id" value="<?php echo $catid; ?>" readonly>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="txtcat" placeholder="Enter Category" value="<?php echo $cat1; ?>">
              </div>
              
              <div class="form-group">
			  <?php
			  if(isset($_REQUEST['ucid']))
			  {
				?>
				<input type="submit" value="UPDATE" name="btnupdate" onclick="return validation();" class="btn btn-primary py-3 px-5">
				<?php
				
			  }else{
			  ?>
                <input type="submit" value="SAVE" name="btnsave" onclick="return validation();" class="btn btn-primary py-3 px-5">
			<?php
				}
			?>
              </div>
            </form>
          
          </div>

          <div class="col-md-6 ">
		<?php 
			$qur=mysql_query("select * from fruit_cat");
			if(mysql_num_rows($qur)>0)
			{
				echo "<table class='table-bordered' cellpadding='10px'>
						<tr>
							<td>CATEGORY ID</td>
							<td>CATEGORY</td>
							<td>CATEGORY STATUS</td>
							<td>UPDATE</td>
							<td>VIEW/HIDE</td>
						</tr>";
				while($q=mysql_fetch_array($qur))
				{
					echo "<tr>";
					echo "<td>$q[0]</td>";
					echo "<td>$q[1]</td>";
					if($q[2]=="0")
					{
						echo "<td>VISIBLE</td>";
						echo "<td><a href='admin_manage_cat.php?ucid=$q[0]'>UPDATE</a></td>";
						echo "<td><a href='admin_manage_cat.php?dcid=$q[0]'>HIDE</a></td>";
					}else{
						echo "<td>INVISIBLE</td>";
						echo "<td><a href='admin_manage_cat.php?ucid=$q[0]'>UPDATE</a></td>";
						echo "<td><a href='admin_manage_cat.php?scid=$q[0]'>SHOW</a></td>";
					}
					echo "</tr>";
				}
				echo "</table>";
			}else{
				echo "<h2>No Record Found</h2>";
			}
		?>
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>