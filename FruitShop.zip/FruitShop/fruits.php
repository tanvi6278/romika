<?php
session_start();
include("header.php");
include("connect.php");


?>
  <div class="hero-wrap hero-bread" style="background-image: url('images/abtbbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread">Fruits</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section">
    	<div class="container">
    		<div class="row justify-content-center">
    			<div class="col-md-10 mb-5 text-center">
    				<ul class="product-category">
    					<li><a href="fruits.php" class="active">All</a></li>
    				<?php
					$qur1=mysql_query("select * from fruit_cat where cat_status='0'");
					while($q1=mysql_fetch_array($qur1))
					{
						?>
						<li><a href="fruits.php?catid=<?php echo $q1[0]; ?>" ><?php echo $q1[1]; ?></a></li>
						<?php
					}
					?>
    				</ul>
    			</div>
    		</div>
    		<div class="row">
    		<?php
			if(isset($_REQUEST['catid']))
			{
				$catid=$_REQUEST['catid'];
				$res1=mysql_query("select * from fruit_detail where fruit_status='0' and cat_id='$catid'");
			}else{
				$res1=mysql_query("select * from fruit_detail where fruit_status='0'");
			}
			if(mysql_num_rows($res1)>0)
			{
				while($r1=mysql_fetch_array($res1))
				{
			?>
				
				<div class="col-md-6 col-lg-4 ftco-animate">
    				<div class="product">
    					<a href="#" class="img-prod"><img class="img-fluid" src="<?php echo $r1[7]; ?>" style="width:348px; height:250px;" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3><a href="#"><?php echo $r1[1]; ?></a></h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">&#8377; <?php echo $r1[5]; ?> /- <?php echo $r1[4]; ?></span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
	    							<a href="fruits_detail.php?fid=<?php echo $r1[0]; ?>" class="buy-now d-flex justify-content-center align-items-center mx-1">
	    								<span><i class="ion-ios-cart"></i></span>
	    							</a>
	    							
    							</div>
    						</div>
    					</div>
    				</div>
    			</div>
    		<?php
				}
			}else{
				echo "<h2>No Fruits Found</h2>";
			}
			?>	

    		
    			
    		</div>
    		
    	</div>
    </section>
	
    <hr>
<?php
include("footer.php");
?>