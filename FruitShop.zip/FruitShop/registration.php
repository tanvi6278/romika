<?php
session_Start();
include("header.php");
include("connect.php");
?>
<script type='text/javascript'>
function validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtname.value=="")
	{
		alert("Enter Your Name");
		form1.txtname.focus();
		return false;
	}else{
		if(!v.test(form1.txtname.value))
		{
			alert("Enter Only Characters in Your Name");
			form1.txtname.focus();
			return false;
		}
	}
	
	if(form1.txtadd.value=="")
	{
		alert("Enter Your Address");
		form1.txtadd.focus();
		return false;
	}
	
	if(form1.txtcity.value=="")
	{
		alert("Enter Your City Name");
		form1.txtcity.focus();
		return false;
	}else{
		if(!v.test(form1.txtcity.value))
		{
			alert("Enter Only Characters in Your City Name");
			form1.txtcity.focus();
			return false;
		}
	}
	
	var v=/^[0-9]+$/
	if(form1.txtmno.value=="")
	{
		alert("Enter Your Mobile No");
		form1.txtmno.focus();
		return false;
	}else if(form1.txtmno.value.length!=10)
	{
		alert("Enter Your Mobile No 10 Digit Long");
		form1.txtmno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtmno.value))
		{
			alert("Enter Only Digits in Your Mobile No");
			form1.txtmno.focus();
			return false;
		}
	}
	
	var v=/^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.([a-zA-Z]{2,4})+$/
	if(form1.txtemail.value=="")
	{
		alert("Enter Your Email ID");
		form1.txtemail.focus();
		return false;
	}else{
		if(!v.test(form1.txtemail.value))
		{
			alert("Enter Valid Email ID");
			form1.txtemail.focus();
			return false;
		}
	}
	
	if(form1.txtpwd.value=="")
	{
		alert("Enter Your Password");
		form1.txtpwd.focus();
		return false;
	}else if(form1.txtpwd.value.length<6)
	{
		alert("Enter Your Password More Than 6 Characters");
		form1.txtpwd.focus();
		return false;
	}else if(form1.txtpwd.value.length>10)
	{
		alert("Enter Your Password Less Than 10 Characters");
		form1.txtpwd.focus();
		return false;
	}
	
	if(form1.selutype.value=="0")
	{
		alert("Select User Type");
		form1.selutype.focus();
		return false;
	}
	
	if(form1.gender[0].checked==false){
		if(form1.gender[1].checked==false){
			alert("Select Gender");
			return false;
		}
	}
}
</script>
<?php
if(isset($_POST['btnregister']))
{
	$name=$_POST['txtname'];
	$add=$_POST['txtadd'];
	$city=$_POST['txtcity'];
	$mno=$_POST['txtmno'];
	$email=$_POST['txtemail'];
	$pwd=$_POST['txtpwd'];
	$utype=$_POST['selutype'];
	$gender=$_POST['gender'];
	
	$res1=mysql_query("select * from user_regis where email_id='$email'");
	if(mysql_num_rows($res1)>0)
	{
		echo "<script type='text/javascript'>";
		echo "alert('Email ID Already Exists');";
		echo "window.location.href='registration.php';";
		echo "</script>";
	}else{
		//auto number code start...
		$res2=mysql_query("select max(user_id) from user_regis");
		$userid=0;
		while($r2=mysql_fetch_array($res2))
		{
			$userid=$r2[0];
		}
		$userid++;
		//auto number code end...
		$query="insert into user_regis values('$userid','$name','$add','$city','$mno','$email','$pwd','$gender','$utype')";
		if(mysql_query($query))
		{
			echo "<script type='text/javascript'>";
			echo "alert('Registration Successfully');";
			echo "window.location.href='login.php';";
			echo "</script>";
		}
	}
}
?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/regisbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" STYLE="color:#000000;">REGISTRATION FORM</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" name="form1" class="bg-white p-5 contact-form">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Name" name="txtname">
              </div>
			   <div class="form-group">
                <textarea name="txtadd" cols="30" rows="3" class="form-control" placeholder="Your Address"></textarea>
              </div>
			  <div class="form-group">
                <input type="text" class="form-control" placeholder="Your City" name="txtcity">
              </div>
			  <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Mobile No" name="txtmno">
              </div>
			  <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Email ID" name="txtemail">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Your Password" name="txtpwd">
              </div>
              <div class="form-group">
                <select class="form-control" name="selutype">
					<option value="0">--Select User Type--</option>
					<option value="1">CUSTOMER</option>
					<option value="2">SUPPLIER</option>
				</select>
              </div>
             <div class="form-group">
                Select Gender: &nbsp;&nbsp;&nbsp;
				<input type="radio" name="gender" value="MALE"> MALE &nbsp;&nbsp;&nbsp;
				<input type="radio" name="gender" value="FEMALE"> FEMALE
              </div>
              <div class="form-group">
                <input type="submit" value="REGISTER" class="btn btn-primary py-3 px-5" name="btnregister" onclick="return validation();">
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
				<img src="images/regis1.gif" style="width:500px; height:500px;">
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>