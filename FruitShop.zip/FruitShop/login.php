<?php
session_start();
include("header.php");
include("connect.php");

if(isset($_POST['btnlogin']))
{
	$email=$_POST['txtemail'];
	$pwd=$_POST['txtpwd'];
	
	$res=mysql_query("select * from admin_detail where email_id='$email' and pwd='$pwd'");
	if(mysql_num_rows($res)>0)
	{
		echo "<script type='text/javascript'>";
		echo "alert('Admin Login Successfully');";
		echo "window.location.href='admin_manage_cat.php';";
		echo "</script>";
	}else{
		$res2=mysql_query("select * from user_regis where email_id='$email' and pwd='$pwd'");
		if(mysql_num_rows($res2)>0)
		{
			$r2=mysql_fetch_array($res2);
			if($r2[8]=="1")
			{
				$_SESSION['userid']=$r2[0];
				if(isset($_SESSION['chkid']))
				{
					echo "<script type='text/javascript'>";
					echo "alert('Customer Login Successfully');";
					echo "window.location.href='checkout_form.php';";
					echo "</script>";
				}else{
					echo "<script type='text/javascript'>";
					echo "alert('Customer Login Successfully');";
					echo "window.location.href='fruits.php';";
					echo "</script>";
				}
			}else if($r2[8]=="2")
			{
				$_SESSION['suppid']=$r2[0];
				echo "<script type='text/javascript'>";
				echo "alert('Supplier Login Successfully');";
				echo "window.location.href='supplier_manage_fruits.php';";
				echo "</script>";
			}
		}else{
			echo "<script type='text/javascript'>";
			echo "alert('Check Your Email ID or Password');";
			echo "window.location.href='login.php';";
			echo "</script>";
		}
	}
}
?>

	<div class="hero-wrap hero-bread" style="background-image: url('images/abtbbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">LOGIN</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" class="bg-white p-5 contact-form">
              <div class="form-group">
                <input type="text" class="form-control" name="txtemail" placeholder="Your Email ID">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" name="txtpwd" placeholder="Your Password">
              </div>
              
              <div class="form-group">
                <input type="submit" value="LOGIN" name="btnlogin" class="btn btn-primary py-3 px-5">
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
				<img src="images/log1.gif" style="margin-left:100px;">
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>