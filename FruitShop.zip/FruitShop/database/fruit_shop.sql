-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 27, 2021 at 07:32 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fruit_shop`
--
CREATE DATABASE IF NOT EXISTS `fruit_shop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fruit_shop`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_detail`
--

CREATE TABLE IF NOT EXISTS `admin_detail` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_detail`
--

INSERT INTO `admin_detail` (`admin_id`, `admin_name`, `email_id`, `pwd`) VALUES
(1, 'admin', 'admin@fruitshop.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bill_detail`
--

CREATE TABLE IF NOT EXISTS `bill_detail` (
  `bill_id` int(10) NOT NULL,
  `bill_date` date NOT NULL,
  `order_id` int(10) NOT NULL,
  `cart_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `bill_amount` int(10) NOT NULL,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cancel_order`
--

CREATE TABLE IF NOT EXISTS `cancel_order` (
  `cancel_id` int(10) NOT NULL,
  `cancel_date` date NOT NULL,
  `order_id` int(10) NOT NULL,
  `cart_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`cancel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cart_detail`
--

CREATE TABLE IF NOT EXISTS `cart_detail` (
  `cart_detail_id` int(10) NOT NULL,
  `cart_id` int(10) NOT NULL,
  `fruit_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `uom` varchar(10) NOT NULL,
  `price` int(10) NOT NULL,
  PRIMARY KEY (`cart_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart_detail`
--

INSERT INTO `cart_detail` (`cart_detail_id`, `cart_id`, `fruit_id`, `qty`, `uom`, `price`) VALUES
(1, 1, 9, 2, 'DOZEN', 28),
(2, 2, 2, 1, 'PCS', 34),
(3, 2, 1, 3, 'DOZEN', 100),
(4, 3, 15, 1, 'KG', 430),
(5, 3, 5, 1, 'KG', 88);

-- --------------------------------------------------------

--
-- Table structure for table `cart_master`
--

CREATE TABLE IF NOT EXISTS `cart_master` (
  `cart_id` int(10) NOT NULL,
  `cart_date` date NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart_master`
--

INSERT INTO `cart_master` (`cart_id`, `cart_date`) VALUES
(1, '2021-05-06'),
(2, '2021-05-06'),
(3, '2021-05-27');

-- --------------------------------------------------------

--
-- Table structure for table `fruit_cat`
--

CREATE TABLE IF NOT EXISTS `fruit_cat` (
  `cat_id` int(10) NOT NULL,
  `category` varchar(50) NOT NULL,
  `cat_status` int(1) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fruit_cat`
--

INSERT INTO `fruit_cat` (`cat_id`, `category`, `cat_status`) VALUES
(1, 'Seasonal Fruits', 0),
(2, 'Regular Fruits', 0),
(3, 'Exotic Fruits', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fruit_detail`
--

CREATE TABLE IF NOT EXISTS `fruit_detail` (
  `fruit_id` int(10) NOT NULL,
  `fruit_name` varchar(50) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `description` varchar(200) NOT NULL,
  `uom` varchar(10) NOT NULL,
  `price` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `fruit_img` varchar(50) NOT NULL,
  `fruit_status` int(1) NOT NULL,
  PRIMARY KEY (`fruit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fruit_detail`
--

INSERT INTO `fruit_detail` (`fruit_id`, `fruit_name`, `cat_id`, `description`, `uom`, `price`, `user_id`, `fruit_img`, `fruit_status`) VALUES
(1, 'Strawberry', 1, 'Strawberry is a red color fruit which is very good for health', 'DOZEN', 100, 1, 'fruit_img/FI1_7193.png', 0),
(2, 'watermelon', 1, 'TheÂ watermelonÂ is a large fruit of a more or less spherical shape. ... It has an oval or spherical shape and a dark green and smooth rind												\r\n', 'PCS', 34, 1, 'fruit_img/FI2_8872.png', 0),
(3, 'Mango', 1, 'Mango  is an evergreen tree in the family  grown for its edible fruit									\r\n', 'KG', 223, 1, 'fruit_img/FI3_4938.png', 0),
(4, 'chikoo', 1, 'ChikooÂ has brown fuzzy skin and is more oval-shaped than its Central American cousins								\r\n', 'KG', 100, 1, 'fruit_img/FI4_1707.png', 0),
(5, 'Java plum', 1, 'Syzygium cumini, commonly known as MalabarÂ plum,Â Java plum, blackÂ plum, jamun or jambolan								\r\n', 'KG', 88, 1, 'fruit_img/FI5_8386.png', 0),
(6, 'pomegranate', 1, 'TheÂ pomegranateÂ plant is a large shrub or small tree that has smooth, evergreen leaves and showy orange to red\r\nflowers.											\r\n', 'PCS', 45, 1, 'fruit_img/FI6_4085.png', 0),
(7, 'Apple', 2, 'TheÂ appleÂ is a pome (fleshy) fruit, in which the ripened ovary and surrounding tissue both become fleshy and edible										\r\n', 'PCS', 61, 1, 'fruit_img/FI7_1114.png', 0),
(8, 'Grapes', 2, 'GrapesÂ are a type of fruit that grow in clusters of 15 to 300, and can be crimson, black, dark blue, yellow, green, orange, and pink.											\r\n', 'KG', 110, 1, 'fruit_img/FI8_9232.png', 0),
(9, 'Banana', 2, 'AÂ bananaÂ is a curved, yellow fruit with a thick skin and soft sweet flesh. If you eat aÂ bananaÂ every day for breakfast,										\r\n', 'DOZEN', 28, 1, 'fruit_img/FI9_8822.png', 0),
(10, 'Oranges', 2, 'AnÂ orangeÂ is a type of citrus fruit that people often eat.Â OrangesÂ are a very good source of vitamin C.									\r\n', 'KG', 157, 1, 'fruit_img/FI10_1191.png', 0),
(11, 'Pineapple', 2, 'Pineapple, Ananas comosus, is an herbaceous biennial or perennial plant in the family Bromeliaceae grown for its edible fruit											\r\n', 'PCS', 104, 1, 'fruit_img/FI11_7490.png', 0),
(12, 'Lemon', 2, 'Lemon,Â CitrusÂ limon, is a small evergreen tree in the family Rutaceae grown for its edible fruit which, among other things											\r\n', 'KG', 176, 1, 'fruit_img/FI12_2859.png', 0),
(13, 'Dragon fruit', 3, 'TheÂ dragon fruitÂ has a dramatic appearance, with bright red, purple or yellow-skinned varieties and prominent scales										\r\n', 'PCS', 143, 1, 'fruit_img/FI13_393.png', 0),
(14, 'Mulberry', 3, 'MulberriesÂ are small to medium sized shrubs or trees with a thick tan-gray ridged trunk and light green leaves which vary in shape depending on variety.													\r\n', 'KG', 984, 1, 'fruit_img/FI14_6825.png', 0),
(15, 'Blackberry', 3, 'blackberryÂ plants have biennial canes (stems) covered with prickles and grow erect, semierect, or with trailing stems.										\r\n', 'KG', 430, 1, 'fruit_img/FI15_7580.png', 0),
(16, 'Blueberry', 3, 'BlueberryÂ is a crown forming, woody, perennial shrub in the family Ericaceae grown for its fruits, or berries, of the same name.											\r\n', 'KG', 230, 1, 'fruit_img/FI16_511.png', 0),
(17, 'Raspberry', 3, 'Raspberry, bramble fruit of the genus Rubus (family Rosaceae). ...Â RaspberryÂ fruits contain iron, vitamin C,									\r\n', 'KG', 530, 1, 'fruit_img/FI17_8651.png', 0),
(18, 'Goosberry', 3, 'GooseberryÂ (Ribes spp.) is a small spiny bush in the family Rosaceae which is grown for its edible fruit of the same name											\r\n', 'KG', 154, 1, 'fruit_img/FI18_8914.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE IF NOT EXISTS `order_detail` (
  `order_id` int(10) NOT NULL,
  `order_date` date NOT NULL,
  `cart_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `delievery_add` varchar(200) NOT NULL,
  `delievery_mno` varchar(10) NOT NULL,
  `order_amount` int(10) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_id`, `order_date`, `cart_id`, `user_id`, `delievery_add`, `delievery_mno`, `order_amount`) VALUES
(1, '2021-05-27', 3, 2, 'dati valsad', '8574123690', 518);

-- --------------------------------------------------------

--
-- Table structure for table `user_regis`
--

CREATE TABLE IF NOT EXISTS `user_regis` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `user_type` int(1) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_regis`
--

INSERT INTO `user_regis` (`user_id`, `user_name`, `address`, `city`, `mobile_no`, `email_id`, `pwd`, `gender`, `user_type`) VALUES
(1, 'Dharmik', 'dati', 'valsad', '7485963210', 'dharmik@yahoo.com', '111111', 'MALE', 2),
(2, 'romika', 'dati', 'valsad', '8574123690', 'romika@yahoo.com', '111111', 'FEMALE', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
