<?php
session_Start();
include("header.php");
include("connect.php");
?>
<script type='text/javascript'>
function validation()
{
	
	
	if(form1.txtadd.value=="")
	{
		alert("Enter Your Delievery Address");
		form1.txtadd.focus();
		return false;
	}
	
	
	var v=/^[0-9]+$/
	if(form1.txtmno.value=="")
	{
		alert("Enter Your Delievery Mobile No");
		form1.txtmno.focus();
		return false;
	}else if(form1.txtmno.value.length!=10)
	{
		alert("Enter Your Delievery Mobile No 10 Digit Long");
		form1.txtmno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtmno.value))
		{
			alert("Enter Only Digits in Your Delievery Mobile No");
			form1.txtmno.focus();
			return false;
		}
	}
	
}
</script>
<?php
if(isset($_POST['btncheckout']))
{
	
	$add=$_POST['txtadd'];
	
	$mno=$_POST['txtmno'];
	$odate=date("Y-m-d");
	$cartid=$_SESSION['cartid'];
	$userid=$_SESSION['userid'];
	$res1=mysql_query("select sum(qty*price) from cart_detail where cart_id='$cartid'");
	$r1=mysql_fetch_array($res1);
	$tamt=$r1[0];
	
	//auto number code start...
	$res2=mysql_query("select max(order_id) from order_detail");
	$orderid=0;
	while($r2=mysql_fetch_array($res2))
	{
		$orderid=$r2[0];
	}
	$orderid++;
	//auto number code end...
	$query="insert into order_detail values('$orderid','$odate','$cartid','$userid','$add','$mno','$tamt')";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Order Generated Successfully');";
		echo "window.location.href='thank_you.php?orderid=$orderid&amt=$tamt';";
		echo "</script>";
	
	}
}
?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/regisbanner1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" STYLE="color:#000000;">CHECKOUT FORM</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	
        
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" name="form1" class="bg-white p-5 contact-form">
             
			   <div class="form-group">
                <textarea name="txtadd" cols="30" rows="3" class="form-control" placeholder="Your Delievery Address"></textarea>
              </div>
			 
			  <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Delievery Mobile No" name="txtmno">
              </div>
			
             
              <div class="form-group">
                <input type="submit" value="CHECKOUT" class="btn btn-primary py-3 px-5" name="btncheckout" onclick="return validation();">
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
				<img src="images/regis1.gif" style="width:500px; height:500px;">
          </div>
        </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>