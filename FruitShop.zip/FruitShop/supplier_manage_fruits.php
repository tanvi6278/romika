<?php
session_Start();
include("supplier_header.php");
include("connect.php");

//auto number code start...
$res=mysql_query("select max(fruit_id) from fruit_detail");
$fid=0;
while($r=mysql_fetch_array($res))
{
	$fid=$r[0];
}
$fid++;
//auto number code end...
?>
<hr/>
<script type="text/javascript">
function validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtname.value=="")
	{
		alert("Please Enter Fruit Name");
		form1.txtname.focus();
		return false;
	}else{
		if(!v.test(form1.txtname.value))
		{
			alert("Please Enter Only Alphabets in Fruit Name");
			form1.txtname.focus();
			return false;
		}
	}
	
	if(form1.selcat.value=="0")
	{
		alert("Please Select Category");
		form1.selcat.focus();
		return false;
	}
	
	if(form1.txtdesc.value=="")
	{
		alert("Please Enter Fruit Description");
		form1.txtdesc.focus();
		return false;
	}
	
	if(form1.seluom.value=="0")
	{
		alert("Please Select Unit Of Measurement");
		form1.seluom.focus();
		return false;
	}
	
	var v=/^[0-9]+$/
	if(form1.txtprice.value=="")
	{
		alert("Please Enter Fruit Price");
		form1.txtprice.focus();
		return false;
	}else if((parseInt(form1.txtprice.value))<=0)
	{
		alert("Please Enter Fruit Price Greater Than 0");
		form1.txtprice.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtprice.value))
		{
			alert("Please Enter Only Digits in Fruit Price");
			form1.txtprice.focus();
			return false;
		}
	}
	
	var fname=document.getElementById('txtimg').value;
	var ext=fname.substr(fname.lastIndexOf(".")+1).toLowerCase().trim();
	if(document.getElementById('txtimg').value=="")
	{
		alert("Please Select Fruit Image");
		return false;
	}else{
		if(!(ext=="jpg" || ext=="png"|| ext=="jpeg"))
		{
			alert("Please Select Fruits Image in Format like jpg jpeg or png");
			return false;
		}
	}
}

function update_validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtname.value=="")
	{
		alert("Please Enter Fruit Name");
		form1.txtname.focus();
		return false;
	}else{
		if(!v.test(form1.txtname.value))
		{
			alert("Please Enter Only Alphabets in Fruit Name");
			form1.txtname.focus();
			return false;
		}
	}
	
	if(form1.selcat.value=="0")
	{
		alert("Please Select Category");
		form1.selcat.focus();
		return false;
	}
	
	if(form1.txtdesc.value=="")
	{
		alert("Please Enter Fruit Description");
		form1.txtdesc.focus();
		return false;
	}
	
	if(form1.seluom.value=="0")
	{
		alert("Please Select Unit Of Measurement");
		form1.seluom.focus();
		return false;
	}
	
	var v=/^[0-9]+$/
	if(form1.txtprice.value=="")
	{
		alert("Please Enter Fruit Price");
		form1.txtprice.focus();
		return false;
	}else if((parseInt(form1.txtprice.value))<=0)
	{
		alert("Please Enter Fruit Price Greater Than 0");
		form1.txtprice.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtprice.value))
		{
			alert("Please Enter Only Digits in Fruit Price");
			form1.txtprice.focus();
			return false;
		}
	}
	
	var fname=document.getElementById('txtimg').value;
	var ext=fname.substr(fname.lastIndexOf(".")+1).toLowerCase().trim();
	if(document.getElementById('txtimg').value!="")
	{
		if(!(ext=="jpg" || ext=="png"|| ext=="jpeg"))
		{
			alert("Please Select Fruits Image in Format like jpg jpeg or png");
			return false;
		}
	}
}
</script>
<?php
if(isset($_POST['btnsave']))
{
	$fid=$_POST['txtfid'];
	$name=$_POST['txtname'];
	$catid=$_POST['selcat'];
	$desc=$_POST['txtdesc'];
	$uom=$_POST['seluom'];
	$userid=$_SESSION['suppid'];
	$price=$_POST['txtprice'];
	$tmppath=$_FILES['txtimg']['tmp_name'];
	$imgpath="fruit_img/FI".$fid."_".rand(100,9999).".png";
	$query="insert into fruit_detail values('$fid','$name','$catid','$desc','$uom','$price','$userid','$imgpath','0')";
	if(mysql_query($query))
	{
		move_uploaded_file($tmppath,$imgpath);
		echo "<script type='text/javascript'>";
		echo "alert('Record Saved Successfully');";
		echo "window.location.href='supplier_manage_fruits.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['ufid']))
{
	$fid=$_REQUEST['ufid'];
	$res1=mysql_query("select * from fruit_detail where fruit_id='$fid'");
	$r1=mysql_fetch_array($res1);
	$name1=$r1[1];
	$catid1=$r1[2];
	$desc1=$r1[3];
	$uom1=$r1[4];
	$price1=$r1[5];
	$fimg1=$r1[7];
}

if(isset($_POST['btnupdate']))
{
	$fruitid=$_REQUEST['ufid'];
	$name=$_POST['txtname'];
	$catid=$_POST['selcat'];
	$desc=$_POST['txtdesc'];
	$uom=$_POST['seluom'];
	$userid=$_SESSION['suppid'];
	$price=$_POST['txtprice'];
	
	if($_FILES['txtimg']['size']>0)
	{
		$tmppath=$_FILES['txtimg']['tmp_name'];
		$imgpath="fruit_img/FI".$fid."_".rand(100,9999).".png";
		$query="update fruit_detail set fruit_name='$name',cat_id='$catid',description='$desc',uom='$uom',price='$price',fruit_img='$imgpath' where fruit_id='$fruitid'";
		move_uploaded_file($tmppath,$imgpath);
	}else{
		$query="update fruit_detail set fruit_name='$name',cat_id='$catid',description='$desc',uom='$uom',price='$price' where fruit_id='$fruitid'";
	}
	
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Updated Successfully');";
		echo "window.location.href='supplier_manage_fruits.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['hfid']))
{
	$fid=$_REQUEST['hfid'];
	$query="update fruit_detail set fruit_status='1' where fruit_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Invisible Successfully');";
		echo "window.location.href='supplier_manage_fruits.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['sfid']))
{
	$fid=$_REQUEST['sfid'];
	$query="update fruit_detail set fruit_status='0' where fruit_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Record Visible Successfully');";
		echo "window.location.href='supplier_manage_fruits.php';";
		echo "</script>";
	}
}
?>
    <section class="ftco-section contact-section bg-light">
      <div class="container">
      	 <div class="col-md-12 ftco-animate text-center">
          	
            <h1 class="mb-0 bread" style="color:#000000;">MANAGE FRUITS</h1>
          </div>
        
        <div class="row block-9">
		
          <div class="col-md-6 order-md-last d-flex">
            <form method="post" name="form1" class="bg-white p-5 contact-form" enctype="multipart/form-data">
              <div class="form-group">
                <input type="text" class="form-control" name="txtfid" placeholder="Enter Fruit Id" value="<?php echo $fid; ?>" readonly>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="txtname" placeholder="Enter Fruit Name" value="<?php echo $name1; ?>">
              </div>
              <div class="form-group">
                <select class="form-control" name="selcat">
					<option value="0">--Select Category--</option>
				<?php
				$qur6=mysql_query("select * from fruit_cat");
				while($q6=mysql_fetch_array($qur6))
				{
					?>
					<option value="<?php echo $q6[0]; ?>" <?php if($catid1==$q6[0]){ echo "selected='selected'"; } ?>><?php echo $q6[1]; ?></option>
					<?php
				}
				?>
				</select>
              </div>
				<div class="form-group">
                <textarea name="txtdesc" cols="30" rows="3" class="form-control" placeholder="Enter Fruit Description"><?php echo $desc1; ?></textarea>
              </div>
           
          
          </div>
 <div class="col-md-6 order-md-last d-flex">
			<div class="bg-white p-5 contact-form">
              <div class="form-group">
                <select class="form-control" name="seluom">
					<option value="0">--Select Unit Of Measurement--</option>
					<option value="KG" <?php if($uom1=="KG"){ echo "selected='selected'"; } ?> >KG</option>
					<option value="PCS" <?php if($uom1=="PCS"){ echo "selected='selected'"; } ?> >PCS</option>
					<option value="DOZEN" <?php if($uom1=="DOZEN"){ echo "selected='selected'"; } ?>  >DOZEN</option>
				</select>
              </div>
              <div class="form-group">
                <input type="number" class="form-control" name="txtprice" placeholder="Enter Fruit Price" value="<?php echo $price1; ?>">
              </div>
              <div class="form-group">
                <input type="file" class="form-control" name="txtimg" id="txtimg">
              </div>
              <div class="form-group">
			  <?php
			  if(isset($_REQUEST['ufid']))
			  {
				?>
				<img src='<?php echo $fimg1; ?>' style="width:200px; height:200px;">
				<input type="submit" value="UPDATE" name="btnupdate" onclick="return update_validation();" class="btn btn-primary py-3 px-5">
				<?php
				
			  }else{
			  ?>
                <input type="submit" value="SAVE" name="btnsave" onclick="return validation();" class="btn btn-primary py-3 px-5">
			<?php
				}
			?>
              </div>
            </form>
          </div>
          </div>
         
        </div>
		
		 <div class="col-md-12 ">
		<?php 
			$userid=$_SESSION['suppid'];
			$qur=mysql_query("select * from fruit_detail where user_id='$userid'");
			if(mysql_num_rows($qur)>0)
			{
				echo "<table class='table-bordered' cellpadding='10px'>
						<tr>
							<td>FRUIT ID</td>
							<td>FRUIT NAME</td>
							<td>CATEGORY</td>
							<td>DESCRIPTION</td>
							<td>UOM</td>
							<td>PRICE</td>
							<td>FRUIT IMAGE</td>
							<td>FRUIT STATUS</td>
							<td>UPDATE</td>
							<td>VIEW/HIDE</td>
						</tr>";
				while($q=mysql_fetch_array($qur))
				{
					echo "<tr>";
					echo "<td>$q[0]</td>";
					echo "<td>$q[1]</td>";
					//echo "<td>$q[2]</td>";
					$qur1=mysql_query("select * from fruit_cat where cat_id='$q[2]'");
					$q1=mysql_fetch_array($qur1);
					echo "<td>$q1[1]</td>";
					echo "<td>$q[3]</td>";
					echo "<td>$q[4]</td>";
					echo "<td>$q[5]</td>";
					echo "<td><img src='$q[7]' style='width:150px; height:150px;'></td>";
					if($q[8]=="0")
					{
						echo "<td>VISIBLE</td>";
						echo "<td><a href='supplier_manage_fruits.php?ufid=$q[0]'>UPDATE</a></td>";
						echo "<td><a href='supplier_manage_fruits.php?hfid=$q[0]'>HIDE</a></td>";
					}else{
						echo "<td>INVISIBLE</td>";
						echo "<td><a href='supplier_manage_fruits.php?ufid=$q[0]'>UPDATE</a></td>";
						echo "<td><a href='supplier_manage_fruits.php?sfid=$q[0]'>SHOW</a></td>";
					}
					echo "</tr>";
				}
				echo "</table>";
			}else{
				echo "<h2>No Record Found</h2>";
			}
		?>
          </div>
      </div>
    </section>

    <hr>
<?php
include("footer.php");
?>